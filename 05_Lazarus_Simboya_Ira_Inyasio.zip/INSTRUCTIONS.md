# Lazarus Simboya Ira Inyasio — Offline and quality engineer

Registration: 25/28180
GitHub (update if needed): lazarus-g03
Branch: `feature/offline-cache-recovery`
Issue: #5

This ZIP is already a complete project tree. Previous members' files and your files sit in their real paths. There are no separate folders to merge.

## 1. Review previous work

Review: **Mojtaba / feature/mobile-ui-navigation**

Review Mojtaba's PR: large text, contrast, empty-question validation, Linking failure alert.

Write a real comment. Example structure:
- What you checked
- One risk or missing acceptance criterion if any
- Approve only if the linked issue is met

## 2. Commit your files

Unzip this archive into the repository. Keep the paths. Commit only the files you own, listed below.

```bash
git checkout -b feature/offline-cache-recovery
git add mobile/src/services/api.ts mobile/src/services/cache.ts mobile/src/services/connectivity.ts mobile/src/services/offlineLookup.ts mobile/src/services/askPipeline.ts mobile/src/services/validation.ts mobile/src/components/SourceBadge.tsx mobile/src/components/ConnectionBanner.tsx mobile/src/components/ErrorRetry.tsx mobile/src/data/members.json docs/OFFLINE_AND_QUALITY.md evidence/signatures/lazarus_sig.png
git commit -m "Add Offline and quality engineer deliverable for G03."
git push -u origin feature/offline-cache-recovery
```

Open a pull request linked to your issue.

## Files you own

- `mobile/src/services/api.ts`
- `mobile/src/services/cache.ts`
- `mobile/src/services/connectivity.ts`
- `mobile/src/services/offlineLookup.ts`
- `mobile/src/services/askPipeline.ts`
- `mobile/src/services/validation.ts`
- `mobile/src/components/SourceBadge.tsx`
- `mobile/src/components/ConnectionBanner.tsx`
- `mobile/src/components/ErrorRetry.tsx`
- `mobile/src/data/members.json`
- `docs/OFFLINE_AND_QUALITY.md`
- `evidence/signatures/lazarus_sig.png`

## Already included from earlier members

- Mohammed Osama Hasan (Product and GitHub lead)
- Nuzha ZainEl-Abdeen Mohammed Ismail (AI and data engineer)
- Ehab Fakhralden Mohamed Hamid (API and integration engineer)
- Mojtaba Abdalitieef Ahmed (Mobile UI and navigation engineer)
